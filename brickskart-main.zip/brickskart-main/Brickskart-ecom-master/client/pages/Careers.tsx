import Layout from "@/components/Layout";

const Careers = () => (
  <Layout>
    <div className="max-w-7xl mx-auto px-4 py-16 text-center">
      <h1 className="text-4xl font-bold mb-4">Careers</h1>
      <p className="text-gray-600 text-lg mb-8">This page content is coming soon.</p>
    </div>
  </Layout>
);

export default Careers;
